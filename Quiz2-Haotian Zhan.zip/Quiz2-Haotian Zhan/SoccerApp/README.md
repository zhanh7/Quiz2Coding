# Quiz 2


## Haotian Zhan 661975315

### Work log:

The idea is to create a web app to show soccer data. 
The finished feature are two:
1. Displaying Json data with the angular mat table.
2. A simple interaction between Mongo and users. 




