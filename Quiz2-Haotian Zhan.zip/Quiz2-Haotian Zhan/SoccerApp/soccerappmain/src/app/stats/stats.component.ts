import {Component} from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import axios from "axios";
declare var require: any;



export interface Teams {
  position: number;
  name: string;
  points: number;
}



const data_sample: Teams[] = [
  {position:1, name:"Atletico", points:73},
  {position:2, name:"Real madrid", points:70},
  {position:3, name:"Barcelona", points:68},
  {position:4, name:"Sevilla", points:67},
  {position:5, name:"Real Sociedad", points:50},
  {position:6, name:"Betis", points:49},
  {position:7, name:"Villareal", points:49},
  {position:8, name:"Granada", points:42},
  {position:9, name:"Osasuna", points:40},
  {position:10, name:"Celta", points:38},
];

@Component({
  selector: 'app-stats',
  templateUrl: './stats.component.html',
  styleUrls: ['./stats.component.css']
})

export class StatsComponent {
  displayedColumns: string[] = ['position', 'name', 'points'];
  dataSource = new MatTableDataSource(data_sample);

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}