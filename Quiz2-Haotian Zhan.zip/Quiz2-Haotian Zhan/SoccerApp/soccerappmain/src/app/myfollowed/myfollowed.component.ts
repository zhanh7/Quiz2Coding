import { Component, OnInit } from '@angular/core';
import axios from "axios";
declare var require: any;

@Component({
  selector: 'app-myfollowed',
  templateUrl: './myfollowed.component.html',
  styleUrls: ['./myfollowed.component.css']
})
export class MyFollowedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


}
