# Quiz 2


## Haotian Zhan 661975315

The installation is simple. 
1. download the code or clone the code from github.
2. run a terminal window, use npm to install node packages including express. 
3. Install angular inside soccerappmain.
4. node serve.js
5. ng serve
